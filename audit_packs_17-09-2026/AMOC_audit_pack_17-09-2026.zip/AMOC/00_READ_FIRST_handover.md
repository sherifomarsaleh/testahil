# AMOC — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | EGP 11.401 |
| Latest known price | EGP 13.54 (6 Sep 2026) |
| Gap | -15.8% |
| Publication status | HELD — more than 10% below the price |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **The forecast margin against the reviewed half.** This study's own record has been
   challenged before on opening its forecast materially below the latest reviewed period, and
   it remains on that gate's outstanding list because it cannot name a mechanism its filings
   support. Attack that first: does the forecast opening rate sit below what the 30 June 2026
   reviewed half implies, and if so what mechanism in the filings justifies it?
2. **The cost path against the price path.** Check that the currency, the inflation and the
   product price form ONE coherent path, not three. A cost stack escalated at domestic
   inflation while the price is held at a currency differential manufactures a margin decline
   out of arithmetic.
3. **The cash.** This is a net-cash company. Confirm the operations are discounted at a rate
   weighted on gross debt and the cash added exactly once — never a net-debt weighting AND a
   cash add-back.
4. **The terminal.** Confirm the asset life behind the terminal maintenance charge is a
   DISCLOSED life from the accounting-policies note, not one chosen by the desk.
5. **NEW, from the 17 September external pass:** a USD 50mn combined heat-and-power
   heads-of-terms was signed on 30 July 2026, reported by two trade outlets and ABSENT from
   the company's own media centre. We have deliberately not modelled it. Is that right?

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
