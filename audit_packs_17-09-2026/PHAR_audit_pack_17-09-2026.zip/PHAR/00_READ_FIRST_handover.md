# PHAR — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | two-sided by provision framing |
| Latest known price | EGP 127.30 (3 Sep 2026) |
| Gap | every branch more than 10% below |
| Publication status | HELD — every branch below the limit |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **The two framings.** The answer is published two-sided on the provision-charge
   normalisation. **Attack whether that is the right axis** — is the provision charge really
   the study's most consequential contested judgement, or is something else?
2. **The biologicals facility.** EIPICO 3 is licensed by the drug and industrial authorities,
   inaugurated, and has launched its first biological product (ADALIMAB) — and the company
   publishes NO volume, utilisation, price, revenue or margin figure for it. We carry it
   top-down for exactly that reason, and two independent searches past three milestones
   confirm the absence. **Is a top-down treatment still right once a plant is producing?**
3. **The credit-loss and provision charge.** Disclosed in total and by type, never by
   counterparty, ageing band or geography. We could not build it bottom-up. **Can you?**
4. **The associates.** Only carrying value, ownership percentage and share of result are
   disclosed; no underlying accounts are published through this company. We normalise rather
   than build up. **Test whether the normalisation is defensible.**
5. **The strike price is stale and we know it.** This study is struck at EGP 127.30 on
   3 September; the share closed August at EGP 129.74 after rising 24.75% in the month and was
   the most-traded main-market name by value. A quarter in a month is fast.

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
