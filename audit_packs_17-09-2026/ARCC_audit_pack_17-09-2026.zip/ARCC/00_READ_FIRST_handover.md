# ARCC — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | EGP 66.530 |
| Latest known price | EGP 76.60 (6 Sep 2026) |
| Gap | -13.1% |
| Publication status | HELD — more than 10% below the price |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **THE OPEN ITEM WE HAVE NAMED OURSELVES, AND THE ONE WE MOST WANT ATTACKED.** This
   study holds no H1-2026 volume. It scales the reviewed half's REVENUE to a full year on
   FY2025's own half-year split per channel, and takes its volume-versus-price split from
   FY2025 relationships. The company's Q2 2026 investor presentation measures it: total
   volumes -6%, revenue per ton +17%, clinker exports -51%, cement utilisation 68% from 74%.
   **Does the calibrated FY2026 revenue carry the wrong split between volume and price?** Both
   are committed drivers and the answer moves both.
2. **The terminal return on capital.** The terminal charges replacement-cost invested capital
   and reinvests at a spread that must be tested against the company's own filed returns on
   book capital (FY2023-25 were 43.9%, 44.3%, 60.6%). If the terminal destroys value where
   the company earns 40%+, say so.
3. **The cost of debt.** The adopted rate is a contractual blend on a 91% euro-denominated
   book, loaded with expected pound depreciation. The trailing FY2025 effective rate computes
   near 5%. We have declared capitalised interest and a mid-year re-basing as the mechanism.
   **Test whether the adopted rate reproduces from the facility lines.**
4. **The export subsidy.** EGP 467.8mn was collected in H1 2026 against EGP 32.6mn for the
   whole of FY2025. We forecast it at the FY2025 disclosed rate and exclude the H1 collection.
   Is that too conservative, or right?
5. Untraced and potentially large: a Ministry of Industry directive of 16 September 2026
   reactivating idle kilns and relaxing the cement quota regime. We have not modelled it.

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
