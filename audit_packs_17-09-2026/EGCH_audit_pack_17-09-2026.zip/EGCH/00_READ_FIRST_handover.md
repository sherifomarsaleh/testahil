# EGCH — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | two-sided: EGP 0.908 (programme stopped) / EGP 8.039 (carried through) |
| Latest known price | EGP 14.41 |
| Gap | every branch more than 10% below |
| Publication status | HELD — every branch below the limit |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **THE BINARY IS THE WHOLE STUDY.** The answer is published two-sided because the
   judgement is binary: is the ANNA capital programme carried through, or stopped? EGP 0.908
   against EGP 8.039, a spread of EGP 4.00 per share, deliberately not averaged. **Attack the
   binary itself** — is it genuinely binary, and are both branches built on the same drivers
   apart from that one decision?
2. **NEW, from the 17 September external pass, and UNVERIFIED:** one engine reports ANNA
   physical completion at **46.60% as of mid-September 2026**, against a 34-month contract
   from 12 October 2023 targeting mechanical completion in June 2027. We could not open the
   source — the company's site does not resolve and the exchange refuses — and the other
   engine did not find it. **If you can reach the ANNA progress disclosure or the state
   auditor's note, that single document decides this study's answer.**
3. **The FY2025/26 accounts were amended downward by ~EGP 101m** after the Central Auditing
   Organization required corrections (9-10 September 2026). The CAO is this company's own
   auditor and this study's terminal record rests on its FY2025 report. **Does the correction
   touch anything this valuation stands on?**
4. **The 30 September AGM proposes scrapping the legacy KIMA 1 units** and selling an
   8.08-feddan quarry plot. Disposal result, residual write-down, lower subsequent
   depreciation, cash proceeds and decommissioning costs each push a different way and none is
   quantified anywhere. **Is the operating asset base correctly separated from legacy
   capacity?**
5. Confirm the inflation-class inputs all derive from one house path — this study has been
   corrected once already for carrying its own ladder inside a derived currency wedge.

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
