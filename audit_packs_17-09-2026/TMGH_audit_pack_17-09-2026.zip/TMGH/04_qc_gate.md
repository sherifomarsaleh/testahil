# TMGH — quality-control gate, edition of 2 September 2026

**Instrument:** Talaat Moustafa Group Holding (EGX:TMGH) · market EG · exchange EGX
**Standard stamped:** 2026.09.01 (`study_numbers.json` → `meta.standard_version`; equals
the live `research_protocol.STANDARD_VERSION`)
**Deliverables audited:** `TMGH_Valuation_Study_02-09-2026.docx` (+ PDF) ·
`TMGH_Valuation_Model_02092026.xlsx` (+ PDF) · `TMGH_Sources_02-09-2026.docx` (+ PDF)

This gate was filled from **outside** the study. Nothing below is copied from
`gate_result.json` or from the session record. The study's own builders, its gate,
its recalculation and its figures were re-run in a sandbox copy of the repository at
`/tmp/.../scratchpad/audit/` so that not one delivered byte was touched, and every
output was diffed against the delivered file. The three repository gates and the
eight rule-level gates were run against the working tree as CI runs them.

**Naming note, recorded because the repository disagrees with itself.** The brief
calls this "edition 2". `engine/build_depth_audit/deliverables_outstanding.json` also
calls it edition 2. `engine/fv_movement.json` records **three** TMGH editions and
places these files at **edition 3** — "WS8 re-issue on the four new modules". The
edition-2 figures quoted in the brief (SALES_FADE 1.15, minority at share of value,
central 69.92, −28.5%) describe a build that was superseded on the same date: the
files on disk carry a cost-of-capital *schedule* (32.37% → 21.93%, not a flat
32.37%), a terminal growth of 7.00% (not 15%), an envelope of 63.70–123.03 (not
47.10–98.17) and an exposed central of **91.83, −6.10%** (not 69.92, −28.5%). Of the
brief's claims, SALES_FADE 1.15 and the value-share minority survive into the
delivered files; the central, the gap and the edition number do not. Verified against
`git log -- engine/tmgh_study/` (commit `73202e29`, "TMGH re-issued on the new
standard") and `fv_movement.json`.

---

## VERDICT: **NOT DELIVERABLE.** Fourteen defects, four of them material to the answer.

The mechanics are in good order — the numbers file, both documents, the workbook and
all four figures reproduce byte-for-byte from the committed builders; the delivered
workbook recalculates 85/85 with zero mismatches; the beta is conforming; the bridge,
lens, macro, cost-of-capital, reverse-read and sign-test records all exist and all
eight repository gates report "no new violations". **Every defect below survived every
one of those gates.** Twelve of the fourteen were found by reading the rendered PDF as
images and by recomputing the study's own claims against its own committed model.

What blocks delivery, shortest list first:

1. **Both delivered documents are dated 1 September 2026** — a day before the edition
   they are. (#3)
2. **The §1.1 bridge does not divide**: EGP 244,183mn over 2,060.7mn shares printed as
   **113.24** where the arithmetic is **118.50**. (#20)
3. **§1.5's comparative narrative is the 1-Sep edition's and is false of this one**
   ("the twenties to sixties" against cases of 43.89–123.03). (#22)
4. **Three long-run growth rates in one document** — 7% in the primary lens, 10% and
   15% in both published cross-checks — and **two revenue legs compounding at 20% and
   22% nominal into a 7% terminal**, against a self-declared
   `growth_at_horizon_end` of 7%. (#12, #13)
5. **"Flat in real terms" is arithmetically false** against the study's own macro path
   (+5.88% a year real, +77.1% over ten years) and appears in the delivered workbook
   and the delivered bibliography. (#12)
6. **The price-solved discount rate is inside `study_numbers.json`** and is read from
   there by `build_xlsx_tmgh.py` — the side door [R-ENF-05] exists to close. (#16)
7. **The sign-test record carries a mis-signed cell** whose correction flips one of
   the two material judgements. (#17)
8. **§1.6 ships an empty table** and §3 states no calibration statistic and no count
   while a per-name record exists. (#26, #7)

---

| # | Item | Verdict | Evidence |
|---|---|---|---|
| 1 | Step 0.0 data-quality gate on every price series | **PASS** | Run inside `beta_regression.own_stock_beta("TMGH","EG","EGX")`, re-executed here: `stock_dq = ["dropped 1 rows carrying a non-positive or non-finite OHLC value (2013-05-07) — vendor fills, not tradeable prices"]`, `index_dq = []`. Both series screened against the EGX ±20% daily limit before any return was computed. |
| 2 | Step 0 calibration under the band record, count printed beside the percentage | **FAIL** | The record exists and is per-name: `assets/data.js` → `BANDS.TMGH = {mkt:"EG", n:57, hits:53, c50:0.4912, c80:0.8246, c90:0.9298, width:1.437, strength:"long", flag:null}` — 53 of 57 resolved three-month forecasts inside the 90% band, 93.0%, two-sided binomial flag `null` (nothing earned to say), width ratio 1.44. **None of it is in the study.** §3 says only "Across the whole book of companies covered on this market the ninety-per-cent band has caught the outcome close to the ninety per cent it promises… nothing is said here." No N, no percentage, no width ratio. [R-CAL-02] requires the count beside the percentage; the depth bar requires the statistics inline in §3. |
| 3 | Delivered documents carry the edition's own date | **FAIL** | Study masthead and bibliography masthead both read **"1 September 2026"**; filenames, `meta.edition_date = "2026-09-02"` and the workbook's own masthead ("Egyptian Exchange · TMGH · Egyptian pounds · **2026-09-02**") say 2 September. Cause: `docx_tmgh.py:37 DATE = "1 September 2026"` is typed, while `build_xlsx_tmgh.py:93` reads `M["edition_date"]`. Consequences in delivered prose: §1.8 "The quote adopted is **26 days** old at the date of this study" against `cost_of_capital_record.disclosures` → "the sovereign quote is **27 days** old (as of 2026-08-06)"; the bibliography's country table says the country-premium file was "read fresh on **1 September 2026**". |
| 4 | 16-section Word document, in the model report's order | **PASS** | 16 Heading-1 sections, 37 headings total, read off the delivered file with `python-docx`: Read first · Headline · Valuation summary · Company overview · 1–1.9 · 2 · 3 · 4 · 5 · 6 · 7 · App A (A.1–A.3) · App B (B.1–B.3) · App C (C.1–C.6) · About this study · Disclosure. Section titles adapted to the class (§3 "Where the price itself could be", §5 "What would move this"); order and count match. |
| 5 | 16-sheet workbook, model report's names and order | **PASS, with one gap named** | `scripts/check_workbook_structure.py`: "MATCHES THE MODEL REPORT (20): … TMGH". Opened directly: sheet names are `research_protocol.MODEL_STUDY['excel_sheets']` in order. **The gap is depth, which that gate does not measure**: 977 non-empty cells and 74 live formulas against the model report's own workbook (`ADNOCLS_Valuation_Model_09082026_public.xlsx`) at 4,112 and 2,160 — 24% of the cells and 3.4% of the formulas. PHDC's current edition carries 2,241 and 175. |
| 6 | Standalone bibliography document with all five required parts | **PASS, with one gap named** | `TMGH_Sources_02-09-2026.docx`, 10 tables: Primary documents (7 rows) · the full input register grouped by layer (income statement 41 · reviewed interim 20 · balance sheet 57 · operating indicators 19 · country 10) · reliability key · Judgements with what would overturn each (7) · What was looked for and not found (7) · Where two sources disagree (3) · How these numbers were checked. All five required parts present. **The gap is depth**: 14,484 characters against the model report's bibliography at 170,371 — 8.5%. Also the country-layer table has no dedicated "As at" column; its dates sit inside the source text. |
| 7 | Every input four-field complete, validated by assertion | **PASS** | Counted at import from `inputs.py`: IS 41 + H1_26 20 + BS 57 + KPI 19 = **137** entries, each carrying `value`, `source`, `date`, `tier` and `unit`; entries missing any required field: **0**. Asserted at import, and the same 137 appear in the delivered bibliography's register. |
| 8 | Numeric traceability — no financial numeral typed into a builder | **FAIL** | The rule holds for the model itself: `build_numbers.py` rebuilds `study_numbers.json` **byte-identical** to the delivered file (sha256 `61493ad6…` both ways; 8,042 leaf keys, 0 key differences, 0 value mismatches). It fails on prose and on two records. Typed financial numerals in builders that reach a reader: `docx_tmgh.py:328` "at a long-run growth rate of **10%**"; `docx_tmgh.py:394` "the twenties to sixties"; `docx_tmgh.py` §1.6 bullets "about **6%** low", "**28%**", "**35** tests", "**58%** low"; `peers.py:61` "cash-negative from **FY2030**"; `docx_bibliography.py:69` "**138** of the **140** documents sought". `contested_judgements.json` and `diagnostics.json` are hand-written JSON with no builder in the directory. |
| 9 | Independent recalculation of the DELIVERED workbook | **PASS** | `recalc.py` opens `TMGH_Valuation_Model_02092026.xlsx` — the delivered edition, not a superseded one — resolves every row by label, and re-derives from the model: **85 checks, 0 mismatches, 0 unparseable**. Coverage: DCF revenue / gross profit / operating profit / FCFF × 10 years (40), attributable profit × 10, EPS × 10, balance-sheet closure × 10, the bridge's three lines, all four published cases reproducing, the seven-point sensitivity grid, and the sheet list. Anything unparseable is reported as FAILURE by construction (`recalc.check`); none was. |
| 10 | Script-built files verified by a cell-by-cell diff against the delivered file | **PASS** | Rebuilt in an isolated copy and diffed against the delivered originals. Workbook: 1,213 cells compared across all 16 sheets, **0 differences**, sheet order identical. Study document: 430 paragraph/table-cell items, **0 differences**. Bibliography: 213 items, **0 differences**. Figures: all four sha256-identical and pixel-identical (`ImageChops.difference(...).getbbox() is None`). |
| 11 | SIGCM clause 1 — historicals from official sources only | **PASS** | Every `source` field across the 137 inputs resolves to one of eight company documents: FY2023, FY2024 and FY2025 consolidated financial statements; the reviewed interim for the three and six months ended 30 June 2026; and the FY2024, FY2025 and 1H-2026 earnings releases — all "via https://talaatmoustafa.com/investor-relations/". No vendor, broker or press figure anywhere in the register. |
| 12 | [R-MACRO-01] one house macro path, every growth rate on it | **FAIL** | `macro_record` records **two** growth lines against a model carrying **four** growth rates, and the two it omits are large. (a) The contracted-sales line is exempted with `exempt_reason` "a physical sales ladder held flat in REAL terms" — `assert_macro_coherence()` skips exempt lines, so the one line off the path is the one nobody tests. Recomputed against the study's own committed ladder (16 / 12 / 9 / 7.5 / 7% then 7%), a flat 1.15 nominal is **−0.86% real in 2026 rising to +7.48% real from 2030, +5.88% a year compounded, +77.1% real over the ten explicit years**. The same false claim ships to readers: the workbook's Assumptions sheet reads "Contracted sales, nominal growth factor a year **(flat in real terms)** … held flat in real terms against the inflation inside the terminal rate", and the bibliography reads "sales are held flat in real terms". The justification is a leftover from the edition whose terminal rate embedded ~14.6% inflation; this edition's terminal inflation is 7.00%. `model.py:57`'s own comment says "Replaced by the house macro path when [R-MACRO-01] lands" — it has landed and the line was not replaced. (b) **Three long-run growth rates in one delivered document**: the DCF terminal at 7.00%, and both published cross-checks at 10% *and* 15% (`lenses.book_and_sustainable_return.cases` keys `rating\|g=10%`, `rating\|g=15%`, `cds\|g=10%`, `cds\|g=15%`; `lenses.normalised_earnings` keys `cap\|rating\|g=10%` …). The cross-check ranges a reader sees — 3.33–12.63 and 15.44–23.77 — are the envelopes across 10% and 15%. Neither rate is in `growth_lines`. |
| 13 | [R-MACRO-01] explicit window runs until growth is within 2pp of terminal | **FAIL** | `macro_record.growth_at_horizon_end = 0.07` is the field `assert_macro_coherence()` tests, and it is asserted rather than measured. Computed from the study's own committed `statements.capacity.full_rows`: total revenue grows **19.8%** in 2035, the last explicit year, against a terminal of 7.00% — **12.8pp apart**. `model.py:183–184` compounds hospitality at exactly 20.0% and other recurring at exactly 22.0% in every one of the ten years with no fade (verified year by year: 20.0/22.0 in all nine growth years), i.e. +12.1% and +14.0% real a year held for a decade against a path ending at 7%. `macro_record.note` states "the recurring legs grow with prices"; they do not. The recurring perpetuity capitalised off that base is **10.9%** of enterprise value on the capacity cases and **30.7%** on the recovery cases. `scripts/check_macro_coherence.py` reports TMGH conforming because it reads the declared field. |
| 14 | [R-COC-01] cost-of-capital schedule from the module, country risk once | **PASS** | `scripts/check_cost_of_capital.py`: "TMGH  EG, 32.37% gliding to 21.93%", conforming. Committed record: regime `transition`; rf observed 23.00% less Egypt's own default spread 3.41% (swap basis) → rf\* 19.59%; ERP 9.41% swap / 13.94% rating, **both published** (§1.8), swap named central; β 1.4718; Ke 33.44% / 37.15%; market-value weights 92.22 / 7.78; forward rates 32.37 → 28.65 → 25.66 → 23.42 → 21.93% then flat, glide fractions the policy-rate path's own cumulative progress; terminal rf 12.50% derived as 7.00% inflation + 5.50% real, never quoted; cumulative factors 0.7554 … 0.1152 with **the terminal brought home on 0.1152, the last explicit year's own factor** (stated in §1.8 and verified in the record). Kd 25.50% pre-tax sits **above** the 23.00% sovereign; `kd_integrity` computes an effective rate independently over two periods (FY2025 24.32%, 1H2026 annualised 25.08%) with its denominator described and non-interest-bearing balances excluded — adopted rate 42bp from the latest and 42bp above the peak, inside both bounds. Sovereign quote 27 days old and the staleness **disclosed** in the record, as the rule requires. |
| 15 | [R-BRIDGE-01] the bridge as a checked record | **PASS on the record** | `scripts/check_bridge.py`: "TMGH  stands on the 2026-06-30 sheet; minority on the value_share basis". Footed independently: 82,628.51 + 75,773.4 − 16,493.0 − 513.9 + 25,228.0 + 1,496.6 + 1,802.8 − 35,643.38 = **134,279.03** = `equity_value`; ÷ 2,060.6538 = **65.1633** = `per_share`. Latest disclosed sheet named with its source (the reviewed 30-June-2026 interim, registered line by line in `inputs.BS`); minority deducted from **equity**, not enterprise value, at its share of value (20.98% filed profit-share proxy) with book and proportional published beside it; cash added once at face with gross weights in the rate and the choice written down; associates at book with the reason; no post-date dividend. One accuracy point: `bridge_record.case` says "the case nearest the published central of 91.83", but 91.83 is the exact midpoint of 65.16 and 118.50 — the two are equidistant, so the stated selection rule does not pick a case. |
| 16 | [R-ENF-05] the reverse read published and kept out of the model | **FAIL** | Published, and the numbers reproduce: re-running `lenses.implied_discount_rate(97.8)` returns **0.290525 / 0.165641**, exactly `diagnostics.json`'s `value` and `value_other_framing`; shown in the Headline, §1.7 and Summary rows 13–14. **But the same quantity is inside the numbers file every builder reads**: `lenses.py` writes it to `lenses.json`, `build_numbers.py:88` folds `lenses.json` into `study_numbers.json` (`lenses.implied_discount_rate`, line 8546), and `build_xlsx_tmgh.py:142–145` reads it back as `LENS["implied_discount_rate"]`. [R-ENF-05] is explicit: "it lives in the study's own diagnostics.json, **NEVER in the numbers file builders read**". `assert_reverse_dcf`'s containment check greps each builder for the literal string `diagnostics.json` and exempts `lenses.py` by name, so this route is invisible to it. Nothing in `valuation.py` consumes the solved rate — the defect is structural, which is what the rule protects. |
| 17 | [R-ENF-05] the sign test measured on the study's own model | **FAIL** | `scripts/check_output_records.py` reports "4 judgements, 2 material, sign test p=0.50" — read off the record. Recomputed on the delivered model, one cell is wrong and its correction flips the sign. `contested_judgements.json` records **terminal growth**: adopted 123.0284, alternative **98.17**. Setting only `model.TERMINAL_GROWTH = 0.15` and re-running `valuation.sotp("capacity", SCHEDULES["cds"])` gives **135.8154** on the adopted minority basis (135.1536 at book). 98.17 is the 02-Sep interim edition's whole answer, which also carried a flat 32.37% rate — two levers, not one. Corrected, the two material judgements are one up and one down, not two up. The other three alternatives do reproduce (65.1633, 118.9724, 118.4978). |
| 18 | [R-LENS-03] one class primary is the central, cross-checks beside it | **PASS on the record, FAIL in the document** | `scripts/check_lens_design.py`: "TMGH  primary dcf, 1 cross-checks", conforming; `lens_record` names the class "real-estate developer, off-plan, point-in-time on handover", the primary DCF published as a range, book value as the one cross-check, and **retires normalised earnings** — "not a lens for this class … The working is kept as a disclosed diagnostic and **carries no value claim**". The delivered document does not say so. §1.4 publishes "Normalised earnings power" with a per-share range of 15.44–23.77; the Valuation-summary page publishes it in a table headed "Cross-check \| What it measures \| **EGP per share**"; §1.5 is titled "Synthesis — **four lenses**, one field"; §4 tabulates four lenses; figure 1 draws it as a bar; the workbook's Fundamental Valuation sheet lists it as one of four. A reader cannot tell it is retired. Nothing is weighted or averaged, so the architecture clause itself holds. |
| 19 | The adopted minority basis is the basis the study displays | **FAIL** | The study adopts value share (`nci_basis_adopted`, `bridge_record.nci.basis`, the fair-value range, the exposed central, the Headline, the Valuation-summary "adopted" column, the workbook Summary and SOTP Bridge sheets). Almost everything else displays **book**: §1.1's per-share line (113.24); §1.7's crux table **and its caption**, which reads "with the minority deducted at its share of value" above `conversion_years_grid`, built from `per_share_nci_book` (`lenses.py:194`); §1.7's text "worth EGP 113.24 … and the faster one EGP 43.89"; §1.9's table and chart (`wacc_grid` stores only `per_share_nci_book` and `per_share_nci_proportional` — the adopted basis is not in the grid at all); figures 1 and 2; §4's cash-flow range "43.89 – 118.97"; the workbook's Fundamental Valuation and Sensitivity sheets; and the reverse read, which bisects on `per_share_nci_book`. A reader comparing the Headline (63.70–123.03) with §4 (43.89–118.97) sees two ranges for one lens. |
| 20 | The bridge in the document foots and divides | **FAIL** | Delivered study §1.1, read as a rendered image: "Value of the whole group's equity 309,000 · Non-controlling interests at their share of value (filed profit share, 21.0%) (64,817) · Equity attributable to TMG's own shareholders **244,183** · Shares in issue, million **2,060.7** · Value per share, EGP **113.24**". 244,183 ÷ 2,060.6538 = **118.50**. `docx_tmgh.py:315` prints `per_share_nci_book` under a value-share equity line. [R-BRIDGE-01](iv) requires the equity to divide to the stated per share. The workbook's SOTP Bridge sheet computes `=B14/B15` and gets 118.50, so the workbook and the document disagree on the same case. `assert_bridge()` passes because the committed record is a different case (cds\|recovery), which does foot. |
| 21 | SIGCM clause 6 — beta from the exchange's published index | **PASS** | `assert_beta_provenance()` re-run through `gate_check.beta_gate()`: β **1.4718**, R² **32.6%**, SE **0.1848**, n **251** weekly points on `W-THU`, window 4.85 years 2021-09-09 → 2026-07-16, `index_file = "raw_indices/EG/EGX30.csv"` (under `raw_indices/`, registered for AE… EG/EGX→EGX30), `index_asof = "2026-07-22"`, `usable = True`, `conforming = True`, `interim_note = None`. Usability gate cleared on all three limbs (n ≥ 24; R² ≥ 5%; SE 0.1848 < \|β\| 1.4718), so no fall to tier 2 or 3 was owed. Blume cross-check 1.3145 disclosed. No study-local regression script exists in the directory. EGX is not the DFM interim case and Egypt is not Qatar, so neither disclosure clause applies. |
| 22 | Prose agrees with the numbers it describes | **FAIL** | §1.5, read as a rendered image: "The cash-flow model and the earnings-power model land **in the twenties to sixties**." The delivered cash-flow cases are 63.70 / 65.16 / 118.50 / 123.03 adopted, 43.89 / 45.75 / 113.24 / 118.97 at book; normalised earnings power is 15.44–23.77. Neither lens lands in the twenties to sixties. Same paragraph: "The relative lens lands **closest to the traded price**" — the relative lens is 34.04–58.00 against 97.80 while the cash-flow envelope *contains* 97.80. Both sentences are true of the 01-Sep edition, whose four cases were 22.30 / 25.62 / 53.05 / 59.67, and are typed at `docx_tmgh.py:392–398`. §1.2's "at a long-run growth rate of 10%" is likewise typed against a model whose long-run growth is 7.00%. |
| 23 | Appendices agree with each other | **FAIL** | Appendix A.3: "On the faster-conversion reading the same statements go cash negative **from 2035**" — correct; the committed `statements.recovery.full_rows` show cash +34,444 in 2034 and **−27,941** in 2035. Appendix B.2, three pages later: "the faster reading goes cash-negative **from FY2030** and needs funding" (typed at `peers.py:61`). Five years apart, in one document. |
| 24 | SIGCM clause 2 / [R-SIGCM-02] — ground-up construction on a driver record | **PASS, with the level stated** | `assert_ground_up()` re-run: **3 revenue lines covering 100.0% of revenue**, share by level **unit 0% · derived 0% · segment 100% · topdown 0%**, and a gap note on every line because every line is below unit. The notes name what is missing and what would close it: no continuous unit series, area, price per square metre or construction cost per square metre for development; keys and average room rate disclosed but not occupancy for hospitality; no leasable area, occupancy or membership count for other recurring. Unit-level is not achieved and is not claimed. |
| 25 | Margins as OUTPUTS with a sourced near-term anchor | **PASS, with one gap named** | Each segment's cost is a disclosed ratio of its own revenue taken from the **reviewed first half of 2026** — development 73.4% of revenue, hospitality 54.6%, other recurring 68.1% — so the gross margins 26.6% / 45.4% / 31.9% are residuals, not inputs, anchored on the most recent reviewed actual rather than a stale full year (workbook Assumptions sheet; §1.6 driver table). **The gap**: TMG discloses no cost per unit, so no per-physical-driver cost stack exists and there is no separate escalator per cost line — the ratios are held flat, which makes cost escalate with revenue by construction. The one escalator that does exist (prices and unit costs on the house inflation ladder, zero real) is recorded in `macro_record`; the two revenue legs that escalate at 20% and 22% are not (see #13). |
| 26 | Fundamental walk-forward evidence in the document | **FAIL** | Delivered table 8 has **one row — the header — and no data**: "Driver \| Observations \| Average error \| Average size of error \| Consistent across the record", with a caption below explaining how to read errors that are not printed. Cause: `build_numbers.py:96` filters `scores.json` for keys matching `asknown\|…\|all`; `engine/tmgh_walkforward/scores.json` is keyed `by_driver / by_horizon / macro_split / by_era / sign_cases / detail`, so `walkforward.driver_scores` is `{}` and `adopted_corrections`, `watch_flags` and `refused` are all `[]`. The record does exist — `by_driver` holds dev_revenue n=35 bias −0.0555 mae 0.276, new_sales n=33 bias −0.8768, finance_cost n=30 bias −1.2237 robust — and matches the typed prose ("about 6% low", "28%", "35 tests", "58% low"), but it never reached the document. Appendix B.3 then points a reader to "sections 1.6 and 1.9" for the walk-forward: 1.6's table is empty and 1.9 is the discount-rate sensitivity. |
| 27 | Walk-forward scope stated in the study | **PASS, with an inconsistency named** | §1.6: "The driver model was rebuilt as it would have stood at each year end **from 2015 to 2024**, projected forward **one to five years**" — ten origins, horizons 1–5, i.e. the FULL scope, corroborated by B.3 ("over ten origins") and by `scores.json` (n=35 for a five-horizon driver). `fv_movement.json` records `scope: "full"` but `origins: "FY2021-FY2025 h=1-5"` for editions 2 and 3, which is neither what the study says nor what `fv_record.py` passes (`"FY2015-FY2024, h=1-5"`). |
| 28 | 3 years historical + 5 years forecast, full FCFF waterfall inline to PV of FCFF | **PASS** | Appendix A.1 carries 2023–2025 as reported and 2026–2030 projected, with years 3–5 published as **ranges** from the walk-forward's own error distribution (2028 revenue 84,517–193,380 on 7 tests; 2029 112,587–315,112 on 6; 2030 90,300–504,013 on 5). §1.1's waterfall runs inline: Revenue → Cost of revenue → Gross profit → Gross margin → Overheads → D&A → Operating profit → Tax on operating profit → Operating profit after tax → add back D&A → less capital spend → less increase in homes built ahead of handover → add increase in money collected ahead of handover → **Free cash flow to the firm → Discount factor → Present value of free cash flow**. It does not stop at FCFF. The table shows the first five of ten explicit years; the remaining five are in the workbook's DCF sheet and are recalculated there (40 of the 85 checks). |
| 29 | SIGCM clause 3 — debt split local vs foreign currency | **PASS** | `cost_of_capital_record.kd_integrity.currency_source`: "all borrowings, facilities and leases on the 30-June-2026 balance sheet are EGP; no foreign-currency tranche is separately disclosed"; `pct_local_currency = 1.0`. Balance-sheet register carries borrowings 16,493.0 and lease liabilities 513.9, both EGP. No local-equivalent adjustment is owed. |
| 30 | SIGCM clause 4 — asset-conversion cycle studied and projected | **PASS** | Collections and build spend are identities on the disclosed movements: `collection_rate_on_book = 7.57%` from the movement in customer advances in the reviewed first half of 2026, and properties under development moved to a 4.0-year cover of cost from the company's own 30-June-2026 position. Both drive the projected balance sheet, and the sheet closes without a plug — recalculated independently for all ten years ("balance sheet closes", 10 of the 85 checks, 0 mismatches; the delivered Appendix A.3 prints the residual as −0.00 / 0.00 in every year). |
| 31 | SIGCM clause 5 — competitors studied, never a source for the subject | **PASS, with one gap named** | `peers.json` carries five Egyptian names with committed price histories and three regional comparators, each with why it is a comparator (Appendix B.1). No competitor figure appears in any of the 137 input sources. **The gap is stated in the document rather than papered over**: "A table of competitors' multiples is deliberately not shown … has not sourced their financial statements, and a competitor multiple built on a denominator nobody sourced is a number wearing a decimal point." The relative lens is therefore built on TMGH's own history. |
| 32 | Sweep Register — primary-source depth | **PASS, with two gaps named** | No Step 2A register exists in the study directory; the obligations are evidenced from the walk-forward's registers and the delivered bibliography. **Company site attempted and logged either way**: `engine/tmgh_walkforward/fetch_attempts.json` records 5 attempts against talaatmoustafa.com — one 200 (the IR index, 2,071,112 bytes, sha256 recorded) and four 404s on the 1H-2009 and 2Q-2017 releases, both failures named in the delivered bibliography. **Audited fiscal years from the filing itself**: 3 (FY2023, FY2024, FY2025 consolidated statements) against a target of 4, plus the reviewed interim to 30 June 2026. **Results releases swept with their statements**: FY2024, FY2025 and 1H-2026 releases all registered. *Gap 1*: the study year's first quarter is **not** swept — `engine/tmgh_walkforward/ir_register.json` holds both "TMG Consolidated financials as of 31 March 2026" and "TMG Holding 1Q26 ER - EN.pdf", and neither appears in the primary-documents table or in any input's source, though the 30-June interim's three-and-six-month columns supersede them for every figure the model uses. *Gap 2*: **no distinct COMPANY_IR tag** — the register holds 19 `ir_presentation` documents, but the delivered primary-documents table has only "Document \| Period it reports" and carries no IR presentation, so a reviewer cannot see how much of the Company ring rests on the IR channel specifically. Also unreproducible: the bibliography's "138 of the 140 documents sought were obtained" is typed at `docx_bibliography.py:69` and I could not derive 138 or 140 from `ir_register.json` (375), `filings/` (25), `fetch_attempts.json` (5) or `refused_documents.json` (empty). |
| 33 | External-reader scrub — zero internal vocabulary, zero verdict tokens | **PASS** | Re-run from outside: `docx_helpers.scrub()` over both delivered documents returns **0 hits across 61,663 characters** (word-boundary matching for short terms, substring for phrases). `band_record.assert_no_verdict_tokens()` run separately over each document's full text including table cells: **passes on both** (46,184 and 15,479 characters). Independent count of PASS / PARITY / FAIL / CRPS as whole words beside the company name: **0**. Calibration evidence is in §3 as plain-language sentences and there is no calibration appendix — though those sentences carry no statistics (#2). |
| 34 | Figure discipline — opaque canvas, every figure inspected as an image | **PASS, with one gap named** | Four figures, each rebuilt in this pass and diffed: sha256-identical to the delivered files and pixel-identical. Opacity verified programmatically on the rendered files — minimum alpha 255 on all four (`Image.getextrema()[3] == (255,255)`), `savefig.transparent=False`, solid `#FBFAF7` canvas. **All four read as rendered images** for this gate. Fig 1 football field: no collisions, the traded-price annotation correctly placed at the inverted axis top. Fig 2 sensitivity: legible, though "traded price 97.80" sits on the dashed line it labels and the green curve crosses it. Fig 3 cone: clean. Fig 4 segments: clean; y-axis ticks print as raw integers (200000, 175000) rather than thousands-separated under an "EGP mn" label. **The gap**: figures 1 and 2 draw only `per_share_nci_book` and `per_share_nci_proportional` (`figures.py:52–56, 100`), so the ADOPTED basis is absent from both — fig 1's dark bars read 82–113, 44–44, 85–119, 45–46 under a caption saying "The four dark bars are the cases this study publishes", while the cases this study publishes are 63.70–123.03. |
| 35 | Table discipline — fixed layout, explicit widths, starved/bloated/over-wide check | **PASS programmatically, with three rendered failures named** | `docx_helpers.column_audit()` re-run over both delivered documents: **33 tables in the study, 10 in the bibliography, 0 problems** — no missing width, no column under 1.0cm, no row over 17.5cm, and the `w:tblGrid` the renderer reads agrees with every cell width to 0.05cm. The audit is width-based, not content-based, and the rendered pages show three columns too narrow for their own text: the Valuation-summary header "**Discou / nt rate**", §1.6's header "**Observatio / ns**", and Appendix A.1's 2030 development revenue "**102,74 / 7**" split across two lines. |
| 36 | Expert appendix at maximum detail | **PASS** | Three experts by method (C.1 the order book as a receivable stream, C.2 net asset value with goodwill excluded, C.3 capitalise only what recurs). Each carries a worldview, when-it-works, when-it-fails, a worked table with every intermediate line (C.1 runs 15 lines from the 491,000 order book to an 83,549 equity value and 40.54 a share), a named sensitivity with numbers (C.1 the conversion period 8/10/12 → 44.56/42.26/40.54) and a falsifier stated in advance ("What would prove this wrong: If TMG discloses a delivery schedule showing the book converting materially faster than twelve years AND cancellations staying below 5% … I would withdraw it"). C.4 cross-examination: four challenges, each answered CONCEDED IN PART / REJECTED / CONCEDED / CONCEDED AS A LIMIT. C.5 the three in one room. C.6 divergence table. Labels are "Expert 1/2/3" only — a regex for a capitalised forename+surname after any Expert label returns **0 hits**. One dangling cross-reference: C.4 says "Section 1.9 sensitises it" of the development margin; §1.9 sensitises the discount rate and the conversion period only. |
| 37 | The central contested judgement computed both ways, never averaged | **PASS** | The conversion period is published at 14 and 10 years in the summary table (four rows), the body (§1.7's ladder 8/10/12/14/16/20 → 37.36 … 150.80), the workbook (Summary rows 7–10, Sensitivity block 2) and an expert's range (C.1's 8/10/12). `READ FIRST` in both the document and the workbook states "The four cases … are never averaged", and `fair_value_range.note` repeats it. The minority is additionally published on three bases. Nothing is weighted into a single figure. |
| 38 | **[R-GAP-01] the answer: the study's own central against the spot it was struck at** | **PASS on the gate, with a material gap named** | `study_numbers.json` → `meta.central = 91.8306`, `meta.spot = 97.80` (EGX close, 23 August 2026), `gap_vs_spot = −6.10%`. `python3 scripts/check_valuation_gap.py` is clean and does **not** list TMGH: "study directories: 24 · readable: 12 · reviewed: 2 · breaching: 5 · unreadable: 12 … OK — no new violations". A review nevertheless exists and covers all eight headings — `GAP_REVIEW_01-09-2026.md` (LATEST FILINGS · BASE YEAR · MACRO COHERENCE · DISCOUNT RATE · TERMINAL · BALANCE SHEET · CLAIMS AGAINST THE RECORD · MULTIPLE CROSS-CHECK) with two dated 02-Sep addenda and the stamp "*AUDITED CENTRAL: 91.8306*", which matches the delivered central exactly. **No `GAP_REVIEW_02-09-2026.md` exists**, and the gate does not require one because the exposed central is inside the band. **The gap named**: 91.8306 is the median of the four cases, and `meta.central_note` says the study "DELIBERATELY PUBLISHES NO CENTRAL … exposed only so [R-GAP-01]'s gate can read the answer". Every one of the four cases a reader is actually shown breaches the two-sided ±10% trigger — 63.6960 (**−34.87%**), 65.1633 (**−33.37%**), 118.4978 (**+21.16%**), 123.0284 (**+25.80%**) — and the only number in the study that does not is the constructed midpoint the gate reads. |
| 39 | The exposed central is described correctly | **FAIL** | `meta.central_note` states the figure is "the median of the four **book-minority** cases". It is not: the four book cases are 43.8906 / 45.7474 / 113.2392 / 118.9724 and their median is **79.4933**. The committed 91.8306 is the median of the four **value-share** cases (65.1633 + 118.4978) ÷ 2. `lens_record.central_note` says only "the median of the four cases" and is correct. |
| 40 | Study-local checks point at the delivered edition [L-066/L-067] | **FAIL** | `recalc.py` correctly opens the 02-09-2026 workbook (#9). Two others do not. `gap_review_calcs.py` — the module `GAP_REVIEW_01-09-2026.md` states computes every figure in it — **raises against the delivered edition**: `AttributeError: 'float' object has no attribute 'discount_factors'` at `valuation.py:65`, because `VAL.discounted` now takes a cost-of-capital schedule and the script still passes a float; its section [4] still prints the superseded diagnosis ("rf\* 16.63%; … the terminal rate embeds 13.63%-15.63% inflation … −15% NOMINAL a year"), and it resets `M.SALES_FADE = 0.85`, the retired value. `fv_record.py`'s `legs()` reads `per_share_nci_book` and returns **43.891 / 79.493 / 118.972**, which is not the triple `fv_movement.json` records for this edition (**63.696 / 91.8306 / 123.0284**, the value-share triple); its `origins` argument is "FY2015-FY2024, h=1-5" against the register's "FY2021-FY2025 h=1-5". Neither script produced the artefact it is committed to produce. |
| 41 | Every non-sourced driver logged to the Driver Ledger | **PASS** | `engine/Fundamental_Driver_Ledger.md` line 103 opens "## TMGH — Talaat Moustafa Group Holding (EGX) · 1 September 2026" and carries the name's driver decisions, including the −58% new-sales miss registered as [L-118]. Lessons: `python3 scripts/check_lessons_register.py` → "[ok] tmgh_walkforward — 17 harvested finding(s), all resolved (7 registered, 10 declined with a reason)", register OK, 103 lessons. |
| 42 | Every gap flagged before issue | **PASS** | `inputs.GAPS` carries four, each with what would close it, and all four are published in the bibliography's "What was looked for and not found": unit economics; the finance-cost split between interest on borrowings and the unwinding of the significant financing component; capital spend by segment; and the Saudi project's own economics. §7 restates them for a reader. |
| 43 | No rating, no price target, no advice | **PASS** | Independent scan of both documents for rating, recommendation and target-price vocabulary: 0 hits, consistent with the study's own scrub. READ FIRST states "It is not advice, it does not tell anyone to buy or sell anything, and it contains no target price." Value is published as a range of four cases with the reason they disagree. |
| 44 | The delivered PDFs are legible renderings of the delivered files | **FAIL** | All three PDFs rendered at 150 dpi and read as images (26 + 11 + 47 pages). The workbook PDF **orphans every continuation column from its row labels**. Summary page 2 shows only "Case \| Enterprise value"; page 3 carries "Equity value (adopted basis)" and "Per share, minority at value share (adopted)" with 244,183/118.50 · 131,255/63.70 · 253,519/123.03 · 134,279/65.16 and **no case labels beside them**, with the note row running off the right edge mid-word. Assumptions page 8 shows "Assumption \| Value" and truncates a label to "…(flat in real term"; the third column, "Where it comes from" — the provenance for every assumption — appears alone on page 9 as a bare list. Segments page 13 shows 3 of the sheet's 8 columns. The `.xlsx` is correct; the PDF a reader receives is not. Separately, study pages 14 and 17 are all but blank, each carrying two lines at the top — the same page-break species the 01-Sep gate recorded. |

---

## The four standing gates, called in the study's own committed code

`gate_check.py` was executed in an isolated copy of the repository (it rebuilds the
documents, the workbook and the figures, so running it in place would have edited the
delivered files this audit exists to inspect). It exited 0 and its table reproduced
the committed `gate_result.json` exactly.

| Gate | Call site | Result |
|---|---|---|
| `assert_beta_provenance` | `gate_check.beta_gate()`, line 33 | **PASS** — β 1.4718 against `raw_indices/EG/EGX30.csv` as of 2026-07-22, n=251 weekly, R² 32.6%, SE 0.1848, usable, conforming |
| `assert_ground_up` | `gate_check.main()`, line 141 | **PASS** — 3 lines, 100% of revenue, 100% segment / 0% unit, gap note on every line |
| `assert_sigcm` | `gate_check.main()`, line 153 | **PASS** — no failures |
| `assert_model_study` | `gate_check.main()`, line 168 | **PASS** — no failures; `external_reader_scrub`, `figure_discipline` and `table_discipline` are computed from the re-run checks, the other six fields are asserted |

`scripts/check_study_provenance.py`: **OK — no new violations.** "study directories:
24 · current study standard: 2026.09.01 · stamped: 5 · known outstanding: 12". TMGH is
neither outstanding nor exempt, so it conforms and is stamped with the live standard.

`python3 -c "import research_protocol as rp; print(rp.STANDARD_VERSION)"` → **2026.09.01**,
which is the version the study records. Worth stating plainly: that stamp predates
[R-MACRO-01], [R-COC-01], [R-LENS-03], [R-BRIDGE-01] and [R-ENF-05], all adopted 2–3
September, and this edition was rebuilt on all five. The stamp cannot distinguish this
study from one built before those rules existed. That is a repository-level
observation, not a defect in this study.

## Repository gates, run from outside

| Command | Result |
|---|---|
| `scripts/check_output_records.py` | OK — no new violations. "TMGH  price implies the single flat discount rate that repro of 29.05% against the study's 32.37%; 4 judgements, 2 material, sign test p=0.50" (conforming, 3 of 24). See #16 and #17: both rows fail on recomputation. |
| `scripts/check_bridge.py` | OK — no new violations. "TMGH  stands on the 2026-06-30 sheet; minority on the value_share basis" (conforming, 5 of 24). |
| `scripts/check_macro_coherence.py` | OK — no new violations. TMGH among the 5 conforming. See #12 and #13: the exempt line and the declared horizon field are what it does not test. |
| `scripts/check_lens_design.py` | OK — no new violations. "TMGH  primary dcf, 1 cross-checks" (conforming, 5 of 24). |
| `scripts/check_cost_of_capital.py` | OK — no new violations. "TMGH  EG, 32.37% gliding to 21.93%" (conforming, 3 of 24). |
| `scripts/check_valuation_gap.py` | OK — no new violations. 24 directories, 12 readable, 2 reviewed, 5 breaching, 12 unreadable; TMGH in none of those lists, i.e. inside the ±10% band on its exposed central. |
| `scripts/check_workbook_structure.py` | OK — no new violations. TMGH among the 20 matching the model report's 16 sheets in order. |
| `scripts/check_calibration_deliverables.py` | OK, **with TMGH waived on the ratchet**: "TMGH — the QC gate is dated 2026-09-01 while the edition is 2026-09-02 (QC_GATE_01-09-2026.md)". `engine/build_depth_audit/deliverables_outstanding.json` carries the same entry. This file is the artefact that closes it. |
| `scripts/check_lessons_register.py` | OK — 103 lessons; "tmgh_walkforward — 17 harvested finding(s), all resolved (7 registered, 10 declined with a reason)". |

TMGH also sits on three ratchets, each allowed and each with its clearing condition
written down: `valuation_inputs_outstanding.json` ("predates the amendment; the block
is added at this name's next run", [R-FCAL-01 AMENDED]); `actuation_outstanding.json`
(walk-forward corrections ran under the previous rule, clears by re-scoring under the
pre-registered one); `deliverables_outstanding.json` (this gate).

## Reproduction of the delivered files

| Artefact | Method | Result |
|---|---|---|
| `study_numbers.json` | `build_numbers.py` re-run in an isolated copy | **byte-identical** — sha256 `61493ad6b3c2e28d…` both ways; 8,042 leaf keys compared, 0 key differences, 0 value mismatches |
| `TMGH_Valuation_Model_02092026.xlsx` | rebuilt, then cell-by-cell diff | 1,213 cells across 16 sheets, **0 differences**; sheet order identical |
| `TMGH_Valuation_Study_02-09-2026.docx` | rebuilt, then paragraph- and table-cell diff | 430 items, **0 differences** |
| `TMGH_Sources_02-09-2026.docx` | rebuilt, then paragraph- and table-cell diff | 213 items, **0 differences** |
| four figures | rebuilt, sha256 + per-pixel diff | **identical** on all four; minimum alpha 255 |
| delivered workbook | `recalc.py`, independent re-derivation from the model | **85 checks, 0 mismatches, 0 unparseable** |

A clean recalculation is necessary and not sufficient, and this edition is the
demonstration: every arithmetic relationship in the workbook reconciles to the last
cell while the document beside it divides 244,183 by 2,060.7 and prints 113.24.

## What the rendered read caught that no programmatic check could

Reading all 84 rendered pages as images, and recomputing the study's own claims
against its own committed model, produced twelve findings that every gate above
reported clean:

1. Both mastheads dated 1 September against a 2 September edition (#3).
2. §1.1's bridge printing 113.24 where 244,183 ÷ 2,060.7 = 118.50 (#20).
3. §1.5's "twenties to sixties" and "the relative lens lands closest to the traded
   price" — the 01-Sep edition's narrative on the 02-Sep numbers (#22).
4. §1.7's caption promising "the minority deducted at its share of value" above a
   table built entirely on the book deduction (#19).
5. Appendix B.2's "cash-negative from FY2030" against Appendix A.3's 2035 (#23).
6. §1.6's walk-forward table shipping as a bare header with a caption (#26).
7. §3 stating no coverage figure and no count while `BANDS.TMGH` holds 53 of 57 (#2).
8. §3 carrying no level-touch ladder — the word "touch" appears nowhere in either
   document, while the model report's §3 carries one with its own explanatory
   paragraph (#4 of the model report's §3 content; recorded here rather than as a
   separate row).
9. Figure 1's four dark bars drawing a range the headline does not publish (#34).
10. Three columns too narrow for their own text — "Discou / nt rate",
    "Observatio / ns", "102,74 / 7" — under a table audit reporting 0 problems (#35).
11. The workbook PDF orphaning every continuation column from its row labels, so the
    per-share figures and the entire provenance column arrive with nothing beside
    them (#44).
12. Two near-blank pages carrying two lines each (#44).

## Asking the question the self-audit cannot: what do the filings disclose that the model does not consume?

Answered against the walk-forward's own document registers, which are the closest
thing this study has to a Sweep Register.

* **The first quarter of the study year.** `ir_register.json` holds "TMG Consolidated
  financials as of 31 March 2026" and "TMG Holding 1Q26 ER - EN.pdf". Neither is in
  the study's primary-documents table nor in any input's source. The 30-June interim
  carries the three- and six-month columns, so nothing the model uses is stale — but
  the release's own operating anchors were never read.
* **Nineteen investor-relations presentations** (`kind: "ir_presentation"`) are held
  and none is consumed. These are the documents the protocol makes mandatory for
  volumes, prices, utilisation and segment data no financial statement carries — and
  the study's largest stated gap is precisely unit economics (area, price per square
  metre, occupancy). The gap is recorded honestly in the delivered documents; whether
  the held presentations close any part of it was not tested.
* **Separate-entity financial statements** (27 in the register) are held and not used.
  For a group where 45.2% of consolidated equity belongs to minorities and the study's
  own second-largest gap is "TMG's economic share of each project company", the
  separate statements are the obvious place to look before proxying the minority's
  claim by its filed profit share.
* **Eleven market updates and five executive-management reports** are held and
  unconsumed.
* **The order-book quality series.** The study cites cancellations "around 4% to 4.5%
  of accumulated sales" in the risk register but consumes no cancellation driver; the
  order book enters the model gross.

None of these is a defect in what the study says. Each is a question the study did not
ask of documents it had already downloaded.

## What is NOT claimed

* **Unit-level ground-up is not achieved and is not claimed.** The record says SEGMENT
  on all three lines, 100% of revenue, with what would close each gap.
* **Peer multiples are not published**, and the document says why.
* **The risk-free rate is 27 days old** at this edition's date. Disclosed in the
  cost-of-capital record and sensitised across 24.37%–40.37% in §1.9 — though the
  document tells a reader 26 days, which is the stale masthead date working through.
* **This gate does not certify the answer.** It certifies that the answer is what the
  committed model produces, that the model reproduces, and that four material defects
  sit between the model and the document a reader receives.

## What must be true before this edition can ship

1. `docx_tmgh.py:37` reads the edition date from the numbers file; both documents
   re-rendered; the "26 days" recomputed.
2. `docx_tmgh.py:315` prints the per-share figure belonging to the equity line above
   it, and §1.7, §1.9, §4, figures 1 and 2 and the workbook's Fundamental Valuation
   and Sensitivity sheets are put on one declared minority basis — or each caption
   says which basis it is on.
3. §1.5 recomputed rather than typed, or deleted.
4. Hospitality and other-recurring growth, and the two cross-check growth rates,
   recorded in `macro_record.growth_lines` on the house path; `growth_at_horizon_end`
   measured from the model rather than declared; the sales ladder either put on the
   path or given an exemption whose stated reason is arithmetically true.
5. `implied_discount_rate` removed from `lenses.json` and read by the workbook builder
   from `diagnostics.json`, per [R-ENF-05].
6. `contested_judgements.json`'s terminal-growth alternative recomputed on this model
   (135.8154, not 98.17) and the sign test re-read.
7. `build_numbers.py:96` re-pointed at `scores.json`'s actual shape so §1.6's table
   carries its rows; the typed walk-forward findings computed from those rows.
8. §3 given TMGH's own band record with its count, and a level-touch ladder.
9. `peers.py:61` computed from the statements, not typed.
10. `gap_review_calcs.py` and `fv_record.py` re-pointed at the delivered edition.
11. `meta.central_note` corrected to name the value-share basis.
12. The workbook PDF re-exported so continuation columns carry their row labels.

---

*Internal QC evidence. Nothing in this file reaches a reader of the study, and nothing
here retro-edits a delivered number. `QC_GATE_01-09-2026.md` covers edition 1 and
stands as it was written.*
