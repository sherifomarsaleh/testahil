# TMGH — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | EGP 91.831 |
| Latest known price | EGP 96.60 (2 Sep 2026) |
| Gap | -4.9% |
| Publication status | HELD — the method is not yet proven; the name is inside the audit band |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **THE LAND BANK, AND IT IS THE FIRST THING WE WANT ATTACKED.** This study carries a
   land bank of 20.0m sq m from the 1H 2026 release, with no record stating its vintage or its
   scope. Both external engines describe a GROUP land bank of roughly 115m sq m rising to
   about 128m sq m after an Iraqi allocation, with projects in Riyadh and Oman beside it.
   **These are almost certainly different quantities and nothing in the study says which.**
2. **AND THE LARGER QUESTION UNDERNEATH IT: does this valuation reach the Saudi, Omani and
   Iraqi land at all?** A developer's lens carries a net-asset read beside the cash flow, and
   a land bank that is printed rather than consumed cannot carry one. In this model the land
   bank is not wired into any arithmetic — it is used inside a sentence. **A land bank that
   moves by 13m sq m changes nothing in a model that never reads it. Is that defensible?**
3. **Noor handovers began 9 September 2026.** Handover is the revenue-recognition trigger for
   a developer on this accounting. **Is the delivery schedule in this model consistent with a
   project entering its operational phase now?**
4. **The minority interest.** This group consolidates subsidiaries it does not wholly own.
   Confirm the minority is deducted from EQUITY value on a value-share basis, never from
   enterprise value and never at historical book alone.
5. The CEO's stated 99.6% collection rate is broadcast commentary, not an audited metric, and
   we have deliberately not consumed it. **Test the collection and cancellation assumptions
   against the filings instead.**

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
