# SCEM — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | see the study |
| Latest known price | EGP 98.52 (6 Sep 2026) |
| Gap | +13.3% |
| Publication status | HELD — the method is not yet proven; the name itself is above the price |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **THIS NAME IS ABOVE THE PRICE, NOT BELOW IT** (+13.3%), which is the rarer and
   less-audited direction. Our own gate fires an audit both ways but blocks publication only
   below. **So attack the optimism directly**: what would have to be true for this study to be
   too high?
2. **The information set stops at 31 March 2026** — and the company's own website carries
   nothing later. There are no June 2026 statements on it as of 17 September 2026.
3. **AND THERE IS A CANDIDATE EXPLANATION WE WANT TESTED.** On 14 September 2026 the exchange
   imposed two EGP 10,000 obligations on this company for non-compliance with Articles 34 and
   48 of the listing rules. A penalty on a periodic-disclosure article, landing in the same
   window as an absent half-year filing, is one coherent story. **Is the company late filing?**
   If so, our information set stops at March because the company stopped filing, not because
   anybody failed to look — and that changes what this study can be held to.
4. **A proposed amendment to the corporate purpose** (board 31 August, no-objection reported
   10 September, EGM to follow) would add quarrying, raw-material export, technical services
   and waste recycling. Every one touches a committed driver. Nothing is quantified.
5. **Seven of seven committed drivers returned no new information** in the external pass.
   Test whether the drivers are therefore stale rather than merely stable.

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
