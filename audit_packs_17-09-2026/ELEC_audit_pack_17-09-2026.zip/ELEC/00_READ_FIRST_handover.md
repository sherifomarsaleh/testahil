# ELEC — EXTERNAL AUDIT HAND-OVER
**Issued 17 September 2026.** One name, one pack.

## WHAT WE ARE ASKING FOR

An adversarial audit of the valuation in this pack. **We are not asking you to confirm it.**
We are asking you to find what is wrong with it, and we would rather be told the study is
wrong than be told it is fine.

**Assume our model is wrong before you assume the market is wrong.** Errors in a discounted
cash flow are not symmetric: a stale base year, an over-charged discount rate, a missed
revenue line, a terminal that declines in real terms, a half-year annualised wrongly and an
unread filing ALL push value down. Where our answer sits far from the traded price, that is a
high-prior-of-defect region and the price is the only instrument in the room that measures it.

**What we do NOT want:** a price target, a rating, a recommendation, a broker estimate, or a
restatement of our own numbers back to us.

## WHERE THIS STUDY STANDS TODAY

| | |
|---|---|
| Published central | EGP 0.3357 |
| Latest known price | EGP 2.12 (6 Sep 2026) |
| Gap | -84.2% |
| Publication status | HELD — by far the largest gap in the wave |

## THE SPECIFIC LINES OF ATTACK, IN PRIORITY ORDER

1. **THE DIVISOR.** This study divides by 3,313.540373mn shares sourced to a DATA VENDOR
   profile dated "2026 (mid)". That is the single number the whole per-share answer rests on
   and its provenance is not the issuer. **Establish the share count from a company or
   exchange document, or tell us it cannot be done.**
2. **THE DIVISOR IS ABOUT TO CHANGE BY ~98%.** The board approved a cash rights issue on
   9 August 2026 — four days AFTER this study was struck: 3,250,000,000 new shares at EGP 0.20
   par for EGP 650mn, taking paid-up capital from EGP 662.708mn to EGP 1,312.708mn. **Did it
   complete? At what price? On what timetable?** Our order-of-magnitude arithmetic makes it
   +4.7% at the bear, -20.0% at the base and -39.1% at the bull — the direction is not uniform.
3. **THE GAP IS -84.2%** and that is the largest in this wave by a wide margin. **Assume our
   model is wrong before assuming the market is.** Every one-way error in a discounted cash
   flow pushes value DOWN: a stale base year, an over-charged discount rate, a missed revenue
   line, a real-terms terminal decline, an unread filing.
4. **The statements are not held.** The company's own website is reachable and carries NO
   investor-relations section at all — 28 pages of product marketing. If you can obtain the
   Q1 and H1 2026 filings, that alone is worth the engagement.
5. Unverified and structural: one engine describes Giza Cable Industries as this group's core
   operating subsidiary. **If true it changes what the accounts cover.**

## WHAT IS IN THIS PACK

| File | What it is |
|---|---|
| `01_valuation_study.*` | The delivered study — the document a reader receives |
| `02_valuation_model.xlsx` | The live workbook. Every fair value recomputes when a driver changes |
| `03_bibliography.*` | The standalone source document: every input with its value, source, date and layer |
| `04_qc_gate.md` | Our own quality gate for this edition, filled from outside the study |
| `05_gap_review.md` | Our eight-heading audit of the gap between our answer and the price |
| `06_driver_impact_17-09-2026.md` | What the September external-news pass did, or did not do, to the drivers |
| `07_external_news/` | The raw returns from two independent search engines, kept apart, and our adjudication of them |

## HOW TO REPORT

One row per finding. **Do not group findings** — two defects in one paragraph read as one.
For each: what is wrong, where (document, page, sheet, cell), what it is worth in per-share
terms if you can price it, and what would have to be true for us to be right instead.

**Price it before you judge it.** A finding worth 0.2% and a finding worth 30% deserve
different attention, and we would rather have the arithmetic than the adjective.

**If you reject a construction, say what you would put in its place.** "Too optimistic" is not
a finding; "the terminal charges a capital intensity the company has never operated at, and
here is its filed history" is.

**Where you cannot obtain a document, say so explicitly and name what you tried.** A search
that was run and came back empty is worth recording. A search nobody ran is not.
